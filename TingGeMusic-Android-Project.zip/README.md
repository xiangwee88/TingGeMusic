# 听歌软件（TingGeMusic）

一个采用深色霓虹风格的 Android 本地音乐播放器项目。

## 第一版功能
- 扫描 Android 媒体库中的本地音乐
- 播放、暂停、上一首、下一首
- 播放进度显示与拖动
- 自动播放下一首
- 不需要网络或账号

## 构建 APK
要求 JDK 17、Android SDK、Gradle 8.9+（推荐 Gradle 8.9）。

在项目根目录运行：
```bash
gradle assembleDebug
```
APK 输出位置：
`app/build/outputs/apk/debug/app-debug.apk`

## 无需本地安装 Android 开发环境的构建方式
1. 将整个项目上传到一个 GitHub 仓库。
2. 进入仓库的 **Actions** 页面。
3. 选择 **Build Android APK**，点击 **Run workflow**（或推送到 main 分支自动构建）。
4. 构建成功后，打开该次 workflow 运行页面，在 **Artifacts** 中下载 `TingGeMusic-debug-apk`。
5. 解压后将 `app-debug.apk` 传到 Android 手机并安装。手机可能会要求允许安装此来源的应用。

## 注意
- 当前版本播放手机中已经存在的音乐文件，不内置歌曲，也不提供未经授权的音乐下载。
- 这是可构建的开发版项目；当前聊天环境没有执行 Android SDK 编译，因此这里不宣称已生成可安装 APK。
- 目前是基础版：播放界面在应用内；退出应用后不保证继续播放。后续可以加入 MediaSession、前台播放服务、锁屏控制、专辑封面、随机/循环模式。
