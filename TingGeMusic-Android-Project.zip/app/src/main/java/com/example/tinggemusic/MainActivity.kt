package com.example.tinggemusic

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 12, 28)
    private val panel = Color.rgb(20, 26, 49)
    private val cyan = Color.rgb(42, 226, 255)
    private val white = Color.rgb(240, 246, 255)
    private val muted = Color.rgb(151, 166, 194)
    private val songs = mutableListOf<Song>()
    private var player: MediaPlayer? = null
    private var current = -1
    private var isPrepared = false
    private var seeking = false
    private lateinit var list: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var playButton: Button
    private lateinit var seekBar: SeekBar
    private lateinit var elapsedView: TextView
    private lateinit var durationView: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && isPrepared) {
                if (!seeking) seekBar.progress = p.currentPosition
                elapsedView.text = time(p.currentPosition.toLong())
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        requestAudioPermission()
        handler.post(tick)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(12))
            setBackgroundColor(bg)
        }
        val brand = TextView(this).apply {
            text = "✦  听歌软件"
            textSize = 27f
            setTextColor(cyan)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(brand)
        root.addView(TextView(this).apply {
            text = "OFFLINE MUSIC  /  YOUR SOUNDSPACE"
            textSize = 10f
            letterSpacing = .12f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(18))
        })

        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(20), dp(18), dp(18))
            background = rounded(panel, dp(20))
        }
        now.addView(TextView(this).apply {
            text = "NOW PLAYING"
            textSize = 10f
            letterSpacing = .2f
            setTextColor(cyan)
        })
        now.addView(TextView(this).apply {
            text = "♫"
            textSize = 64f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setPadding(0, dp(8), 0, dp(4))
        })
        titleView = TextView(this).apply {
            text = "选择一首歌曲"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        artistView = TextView(this).apply {
            text = "从下方本地音乐库开始播放"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(14))
        }
        now.addView(titleView)
        now.addView(artistView)
        seekBar = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
            thumbTintList = android.content.res.ColorStateList.valueOf(cyan)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && isPrepared) elapsedView.text = time(progress.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    if (isPrepared) player?.seekTo(sb?.progress ?: 0)
                    seeking = false
                }
            })
        }
        now.addView(seekBar)
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        elapsedView = TextView(this).apply { text = "0:00"; textSize = 11f; setTextColor(muted) }
        durationView = TextView(this).apply {
            text = "0:00"; textSize = 11f; setTextColor(muted); gravity = Gravity.END
        }
        times.addView(elapsedView, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(durationView, LinearLayout.LayoutParams(0, -2, 1f))
        now.addView(times)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        controls.addView(controlButton("⏮", 22) { previous() })
        playButton = controlButton("▶", 28) { togglePlay() }.apply {
            setTextColor(bg)
            background = rounded(cyan, dp(28))
        }
        val playParams = LinearLayout.LayoutParams(dp(66), dp(54)).apply {
            setMargins(dp(18), 0, dp(18), 0)
        }
        controls.addView(playButton, playParams)
        controls.addView(controlButton("⏭", 22) { next() })
        now.addView(controls)
        root.addView(now, LinearLayout.LayoutParams(-1, -2))

        val libraryHeader = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(10))
        }
        libraryHeader.addView(TextView(this).apply {
            text = "本地音乐"
            textSize = 18f
            setTextColor(white)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        libraryHeader.addView(TextView(this).apply {
            text = "离线播放"
            textSize = 11f
            setTextColor(cyan)
        })
        root.addView(libraryHeader)

        val scroll = android.widget.ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun controlButton(label: String, size: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = size.toFloat()
            setTextColor(cyan)
            background = rounded(panel, dp(18))
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(6), 0, dp(6), 0)
            setOnClickListener { action() }
        }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), 100)
        } else loadSongs()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            Toast.makeText(this, "需要允许访问音频，才能读取手机里的歌曲", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadSongs() {
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(collection, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")
            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    songs.add(Song(id, it.getString(titleCol) ?: "未知歌曲",
                        it.getString(artistCol) ?: "未知歌手",
                        ContentUris.withAppendedId(collection, id), it.getLong(durationCol)))
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "读取歌曲失败，请检查音频权限", Toast.LENGTH_SHORT).show()
        }
        renderSongs()
    }

    private fun renderSongs() {
        list.removeAllViews()
        if (songs.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "暂时没有找到歌曲\\n请先将 MP3、M4A 等音频放进手机，再重新打开软件。"
                textSize = 13f
                setTextColor(muted)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(24), dp(14), dp(24))
            })
            return
        }
        songs.forEachIndexed { index, song ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = rounded(panel, dp(14))
                val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
                layoutParams = params
                isClickable = true
                setOnClickListener { playAt(index) }
            }
            item.addView(TextView(this).apply {
                text = "♫"
                textSize = 22f
                setTextColor(cyan)
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(40), dp(42)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
            labels.addView(TextView(this).apply {
                text = song.title
                textSize = 14f
                setTextColor(white)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            labels.addView(TextView(this).apply {
                text = "${song.artist}  ·  ${time(song.duration)}"
                textSize = 11f
                setTextColor(muted)
                maxLines = 1
            })
            item.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            item.addView(TextView(this).apply {
                text = if (index == current) "♫" else "›"
                textSize = 22f
                setTextColor(cyan)
            })
            list.addView(item)
        }
    }

    private fun playAt(index: Int) {
        if (index !in songs.indices) return
        releasePlayer()
        current = index
        val song = songs[index]
        titleView.text = song.title
        artistView.text = song.artist
        durationView.text = time(song.duration)
        elapsedView.text = "0:00"
        seekBar.progress = 0
        playButton.text = "Ⅱ"
        isPrepared = false
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@MainActivity, song.uri)
                setOnPreparedListener {
                    isPrepared = true
                    seekBar.max = it.duration
                    durationView.text = time(it.duration.toLong())
                    it.start()
                    playButton.text = "Ⅱ"
                }
                setOnCompletionListener { next() }
                setOnErrorListener { _, _, _ ->
                    Toast.makeText(this@MainActivity, "这首歌曲无法播放", Toast.LENGTH_SHORT).show()
                    true
                }
                prepareAsync()
            }
            renderSongs()
        } catch (_: Exception) {
            Toast.makeText(this, "无法打开这首歌曲", Toast.LENGTH_SHORT).show()
            playButton.text = "▶"
        }
    }

    private fun togglePlay() {
        val p = player
        if (p == null) {
            if (songs.isNotEmpty()) playAt(if (current >= 0) current else 0)
            else Toast.makeText(this, "请先添加歌曲到手机", Toast.LENGTH_SHORT).show()
            return
        }
        if (!isPrepared) return
        if (p.isPlaying) {
            p.pause()
            playButton.text = "▶"
        } else {
            p.start()
            playButton.text = "Ⅱ"
        }
    }

    private fun next() {
        if (songs.isNotEmpty()) playAt(if (current < 0) 0 else (current + 1) % songs.size)
    }

    private fun previous() {
        if (songs.isNotEmpty()) {
            if (isPrepared && (player?.currentPosition ?: 0) > 3000) player?.seekTo(0)
            else playAt(if (current <= 0) songs.lastIndex else current - 1)
        }
    }

    private fun releasePlayer() {
        isPrepared = false
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun time(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        releasePlayer()
        super.onDestroy()
    }
}
